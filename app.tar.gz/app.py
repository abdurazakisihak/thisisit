import flet as ft
from flet import AppBar, ElevatedButton, Page, Text, View, colors
from telethon import TelegramClient, functions  # Import the functions module
import sys
import re
from asyncio import new_event_loop, run
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError

# Rest of your code...

# You can get Telegram development credentials in Telegram API Development Tools 
api_id = 8
api_hash = "7245de8e747a0d6fbe11f7cc14fcc0bb"
sess = '1BJWap1sBuypGpyiq0lAvBPpZe4hjK9kMnMh40dOe7GdKyJ9KLgz-jsfmEwuhYuUb612AYBv3U5zfcIr-_yzCYcdHOXmPNjbVZGz3Wx5_sakwagCYYInrdLE_EwuaRbNf6Z5Cr6I1a0XgxkWzjJfzdH0bQ3XNZNRY7nn75DThRby--pxcR16A0kEg3YE5b-_B91UQa1fyqMIvFqz90r1KSc3NB-UBH1FqpQp2VAAamz2spTHRx-QyxVL1RDc9snlDbStrwWmByEqVN18pxN_DOzFzyDcZa86MNx49sPU8ZwS4K1PodK2NL9BRyjfRGVADrpfgEe46m9vZ9Py3XabEHFXxbrfCqzw='
client = TelegramClient(StringSession(sess), api_id, api_hash)

async def get_channel_posts(channel_username, page):
    try:
        # Get the channel entity by its username
        channel = await client.get_entity(channel_username)
        
        # Fetch the latest 10 messages from the channel
        messages = await client(functions.messages.GetHistoryRequest(
            peer=channel,
            limit=10,  # You can adjust the limit as needed
            offset_id=0,
            offset_date=None,
            add_offset=0,
            max_id=0,
            min_id=0,
            hash=0,
        ))
        
        # Display the channel posts on the homepage
        for message in reversed(messages.messages):
            page.views[-1].content.append(ft.Text(value=message.message))
        
        # Update the page
        page.update()
    except Exception as e:
        print("Error fetching channel posts:", str(e))

def main(page: Page):
    loop = new_event_loop()
    page.title = "Tel"
    
    def startup_async():
        loop.run_until_complete(startup())
    
    def get_verif_async(phone_num):
        loop.run_until_complete(get_verification_code(phone_num))
    
    def set_verif_async(phone_number, code_num):
        loop.run_until_complete(set_verification_code(phone_number, code_num))
    
    def enter_password(pass_num):
        loop.run_until_complete(set_password(pass_num))
        page.go("/homepage")
    
    async def get_verification_code(phone_number):
        if phone_number and re.match(r"^\+\d+$", phone_number):
            await client.send_code_request(phone_number)
            page.go("/code_screen") 
        else:
            page.add(ft.Text(value='error'))
    
    async def set_password(pd):
        await client.sign_in(password=pd)
        print("Successfully logged in")
        print(client.session.save())
    
    async def set_verification_code(phone_number, code_number):
        try:
            await client.sign_in(phone_number, code_number)
            page.go("/homepage") 
        except SessionPasswordNeededError as e:
            page.go("/password_screen")
    
    async def startup():
        await client.connect()
        if not await client.is_user_authorized():
            page.route = "/login_screen"
        else:
            page.route = "/homepage"    
    
    def route_change(e):
        page.views.clear()
        
        if page.route == "/login_screen":
            global phone_num_field
            phone_num_field = ft.TextField(hint_text="Your phone number", expand=True)
            page.views.append(
                View(
                    "/login_screen",
                    [
                        AppBar(title=Text("Login"), bgcolor=colors.SURFACE_VARIANT),
                        phone_num_field,
                        ElevatedButton(text='Get code', on_click=lambda x: get_verif_async(phone_num_field.value))                       
                    ],
                )
            )
        
        if page.route == "/code_screen":
            code_field = ft.TextField(hint_text="Code", expand=True)
            page.views.append(
                View(
                    "/code_screen",
                    [
                        AppBar(title=Text("Code"), bgcolor=colors.SURFACE_VARIANT),
                        code_field,
                        phone_num_field,
                        ElevatedButton(text='Enter code', on_click=lambda x: set_verif_async(phone_num_field.value, code_field.value)),
                        ElevatedButton(text='Back', on_click=lambda x: page.go("/login_screen"))                      
                    ],
                )
            )
        
        if page.route == "/password_screen":
            password_field = ft.TextField(hint_text="Password", expand=True)
            page.views.append(
                View(
                    "/password_screen",
                    [
                        AppBar(title=Text("Password"), bgcolor=colors.SURFACE_VARIANT),
                        password_field,
                        ElevatedButton(text='Enter password', on_click=lambda x: enter_password(password_field.value)),
                        ElevatedButton(text='Back', on_click=lambda x: page.go("/code_screen"))                      
                    ],
                )
            )  
        
        if page.route == "/homepage":
            page.views.append(
                View(
                    "/homepage",
                    [
                        AppBar(title=Text("Homepage"), bgcolor=colors.SURFACE_VARIANT),
                    ],
                )
            )
        
        page.update()
    
    def view_pop(e):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)
    
    # Async script startup
    startup_async()
    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route)

ft.app(target=main, view=ft.AppView.WEB_BROWSER)